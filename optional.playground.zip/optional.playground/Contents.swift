import UIKit

var greeting = "Hello, playground"

// exercise 1

var secretMessage: String? = "This is a secret message"

var box: String? = "A"

// nil col = safely unwrap

print(box ?? "there is no secret")

// force unwarp

print(box!)

if secretMessage != nil {
    print("Force unwrapped message: \(secretMessage!)")
} else {
    print("No secret message found.")
}

//
// exercise 2


func performLogin(username: String?, password: String?){
    
    if username == nil && password == nil{
        print("login failed😞")
    } else if (username == "Razan" && password == nil) || (username == nil && password == "123"){
        print("login failed😞")
    } else {
        print("LOGIN SUCCESSFULL 😎")
    }
    
}



performLogin(username: "Razan", password: "123")
